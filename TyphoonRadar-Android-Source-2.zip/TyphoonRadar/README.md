# 台风雷达 Typhoon Radar — Android starter project

当前交付是 **可交互的 Android WebView 原型 + Android Studio 工程源代码**，不是已验证的商业成品 APK。界面内的台风数据和路径均为明确标注的演示内容，不可用于防灾决策。

## 技术方案
- Android 原生壳：Kotlin + WebView
- 最低 Android API：29（Android 10）
- UI：HTML/CSS/JavaScript 本地资源，可离线打开原型
- 权限：联网与网络状态

## 如何构建 APK
1. 在电脑安装 Android Studio（建议稳定版）及 Android SDK 35。
2. 用 Android Studio 打开本目录 `TyphoonRadar`。
3. 等待 Gradle 同步完成；若提示 JDK，选择 Android Studio 内置 JDK 17。
4. 选择 `Build > Build Bundle(s) / APK(s) > Build APK(s)`。
5. Debug APK 通常位于 `app/build/outputs/apk/debug/app-debug.apk`。

也可在具备 Android SDK、JDK 17 和网络依赖的环境执行：

```bash
gradle assembleDebug
```

本工程未包含 Gradle Wrapper JAR，需使用 Android Studio 或已安装的 Gradle。此运行环境未检测到 Android SDK/Gradle，因此这里没有声称已成功编译 APK。

## 商业版上线前的必做事项
- 确定并签署气象数据供应/授权协议；验证 API 许可、调用限制、再分发权和 SLA。
- 实现后台服务：数据源适配、标准化、缓存、数据质量检查、来源/时间戳、故障降级。
- 接入可信台风最佳路径/预报、官方预警、卫星云图和雷达图层；禁止把演示值呈现为实况。
- 地图、路径预测锥、风圈和降雨图层应有单位、图例、有效时间和来源标识。
- 加入推送通知、城市订阅、后台刷新、隐私政策、日志/崩溃分析、无障碍与多机型测试。
- 发布前进行安全审查、签名密钥管理、性能/耗电测试与气象专业审核。

## 项目结构
- `app/src/main/java/.../MainActivity.kt`：Android WebView 容器
- `app/src/main/assets/index.html`：交互式原型界面
- `app/src/main/AndroidManifest.xml`：权限与入口
- `app/build.gradle`：Android 构建配置
